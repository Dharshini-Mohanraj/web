ABC College HTML Frames Project

Files:
- index.html: Main frameset page
- header.html: College heading
- menu.html: Navigation links
- home.html: Welcome page
- courses.html: Courses page
- contact.html: Contact page

How to run:
1. Extract this ZIP file.
2. Keep all files in the same folder.
3. Open index.html in a browser.

Note: <frameset> and <frame> are obsolete in HTML5, but are included here for learning traditional HTML frames.
